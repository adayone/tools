#
#   This file defines a user time interpolation featurre generator for movielen dataset
#
import sys

#make features,including user feature and item feature
#the input file format:userid \t itemid \t rate \t day\n
#the output format:rate \t number of global features \t number of user features \t number of item features \t gfid:gfvalue ... ufid:ufvalue ... ifid:ifvalue ... \n
def mkfeature( fin, fout, num_user, first_day, last_day ):
    fi = open( fin , 'r' )
    fo = open( fout, 'w' )
    
    for line in fi:
        arr  =  line.split()               
        uid  =  int(arr[0].strip())-1
        iid  =  int(arr[1].strip())-1
        score=  int(arr[2].strip())
        time = int(arr[3].strip())
        day = time/(24*60*60)
        length = last_day - first_day
        fo.write( '%d\t0\t2\t1\t' % ( score ))
        fo.write('%d:%.6f %d:%.6f %d:1\n' %(uid*2,float(last_day-day)/length,uid*2+1,float(day-first_day)/length,iid))
    
    fi.close()
    fo.close()
    print 'generation end'

if __name__ == '__main__':
    if len(sys.argv) < 3:
	print 'usage:<input> <output>'
	exit(-1)
    fin = sys.argv[1]
    fout = sys.argv[2]
    #for movielen 100K dataset
    num_user = 943
    first_day = 10124
    last_day = 10338
    #make features and print them out in file fout 
    mkfeature( fin, fout, num_user, first_day, last_day )
