#!/bin/bash

# clean all the trace of demo
rm pred.txt
rm *.svdpp
rm *.group
rm *.order
rm *.shuffle
rm *.model
rm *.*feature
rm *.*buffer
