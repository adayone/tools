#
#   This file adds temporal feature of item day bin to the basic svd for movielen feature
#
import sys

#make features,including global feature,user feature and item feature
#the input file format:userid \t itemid \t rate \t day\n
#the output format:rate \t number of global features \t number of user features \t number of item features \t gfid:gfvalue ... ufid:ufvalue... ifid:ifvalue...\n
def mkfeature( fin, fout, num_item, start_day, end_day, bin_size):
    fi = open( fin , 'r' )
    fo = open( fout, 'w' )
    
    days = end_day-start_day+1
    if days%bin_size == 0:
        bin_num = days/bin_size
    else:
        bin_num = days/bin_size + 1
    print bin_num * num_item
    for line in fi:
        arr  =  line.split()               
        uid  =  int(arr[0].strip())-1
        iid  =  int(arr[1].strip())-1
        score=  int(arr[2].strip())
	time =   int(arr[3].strip())
        day = time/(24*60*60)
        fo.write( '%d\t1\t1\t1\t' % ( score ))
        fo.write( '%d:1 %d:1 %d:1\n' %( iid*bin_num+(day-start_day)/bin_size,uid,iid  ))
    fi.close()
    fo.close()

    print 'generation end'

if __name__ == '__main__':
    if len(sys.argv) < 3:
	print 'usage:<input> <output>'
	exit(-1)
    fin = sys.argv[1]
    fout = sys.argv[2]
    #for movielen 100K dataset
    num_user = 943
    num_item = 1682
    start_day = 10124
    end_day = 10338
    bin_size = 10
    #make features and print them  out in file fout 
    mkfeature( fin, fout, num_item, start_day, end_day, bin_size )
