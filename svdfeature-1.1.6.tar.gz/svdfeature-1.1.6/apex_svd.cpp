/*
 *  Copyright 2009-2010 APEX Data & Knowledge Management Lab, Shanghai Jiao Tong University
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

/*!
 * \author Tianqi Chen: tqchen@apex.sjtu.edu.cn
 */
#define _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_DEPRECATE
#include "apex_svd.h"
#include <cstring>

namespace apex_svd{
    using namespace apex_tensor;
    using namespace apex_utils;
};

namespace apex_svd{
    // parameter set, used for detailed tuning
    class ParameterSet{
    private:
        // weight decay
        std::vector<float>    wd;
        // bound for index 
        std::vector<unsigned> bound;
        int  prefix_lenA, prefix_lenB;
        char prefixA[ 256 ], prefixB[ 256 ];
    public :
        ParameterSet( const char *prefixA, const char *prefixB ){
            strcpy( this->prefixA, prefixA );
            strcpy( this->prefixB, prefixB );
            this->prefix_lenA = static_cast<int>( strlen( prefixA ) );
            this->prefix_lenB = static_cast<int>( strlen( prefixB ) );
        }
        inline void set_param( const char *name, const char *val ){
            if( !strncmp( name, prefixA, prefix_lenA ) ){
                name += prefix_lenA;
            }else{
                if( !strncmp( name, prefixB, prefix_lenB ) ){
                    name += prefix_lenB;
                }else return;
            }

            if( !strcmp( "bound", name ) ){
                unsigned bd = (unsigned)atoi(val);
                apex_utils::assert_true( bd > 0, "can't give 0 as bound" ); 
                apex_utils::assert_true( bound.size()==0||bound.back() < bd , "bound must be given in order" );
                apex_utils::assert_true( bound.size()+1 == wd.size() , "must specifiy wd in each range" );
                bound.push_back( bd - 1 );
            }
            if( !strcmp( "wd", name ) ){
                apex_utils::assert_true( wd.size() == bound.size(), "setting must be exactly" );
                wd.push_back( (float)atof(val) );
            }
        }
        inline float get_wd( unsigned gid, float wd_default ) const{
            if( bound.size() == 0 ) return wd_default;
            size_t idx = std::lower_bound( bound.begin(), bound.end(), gid ) - bound.begin();
            apex_utils::assert_true( idx < bound.size() , "bound set err" );
            return wd[ idx ];
        }
    };
};
// this file defines the main algorithm of toolkit
namespace apex_svd{    
    class SVDFeature: public ISVDTrainer{
    private:
        SVDModel model;
        SVDTrainParam param;            
        CTensor1D tmp_ufactor, tmp_ifactor;
        // extend hierachical feature associated with each user/item
        SparseFeatureArray<float> feat_user, feat_item;
    private:
        int round_counter;
    private:
        char name_feat_user[ 256 ];
        char name_feat_item[ 256 ];
    private:
        // data structure used for lazy decay
        unsigned sample_counter;
        unsigned *ref_user, *ref_item, *ref_global;
    private:
        // SVD++ style
        float norm_ufeedback;
        float tmp_ufeedback_bias, old_ufeedback_bias;
        CTensor1D tmp_ufeedback, old_ufeedback;
    private:
        // data structure for detail weight decay tuning
        ParameterSet u_param, i_param, g_param;
    public:
        SVDFeature( const SVDTypeParam &mtype ):
            u_param("up:","uip:"),i_param("ip:","uip:"),g_param("gp:","gp:"){
            model.mtype = mtype;
            strcpy( name_feat_user, "NULL" );
            strcpy( name_feat_item, "NULL" );
            this->round_counter = 0;
        }
        virtual ~SVDFeature(){
            tensor::free_space( tmp_ufactor );
            tensor::free_space( tmp_ifactor );
            // lazy decay
            if( param.reg_global >= 4 ) {
                delete [] ref_global;
            } 
            if( param.reg_method >= 4 ){
                delete [] ref_user; 
                if( model.param.common_latent_space == 0 ) delete [] ref_item;
            }
            // SVD++ style
            if( model.mtype.model_type == svd_type::SVD_FEATURE_PLUS ){
                tensor::free_space( tmp_ufeedback );
                tensor::free_space( old_ufeedback );
            }
            model.free_space();
        }
    public:
        // model related interface
        virtual void set_param( const char *name, const char *val ){
            if( !strcmp( name,"feature_user" )) strcpy( name_feat_user  , val ); 
            if( !strcmp( name,"feature_item" )) strcpy( name_feat_item  , val ); 
            param.set_param( name, val );
            u_param.set_param( name, val );
            i_param.set_param( name, val );
            g_param.set_param( name, val );
            if( model.space_allocated == 0 ){
                model.param.set_param( name, val );
            }
        }
        // load model from file
        virtual void load_model( FILE *fi ) {
            model.load_from_file( fi );
        }
        // save model to file
        virtual void save_model( FILE *fo ) {
            model.save_to_file( fo );
        }
        // initialize model by defined setting
        virtual void init_model( void ){
            model.alloc_space();
            model.rand_init();
        }
        // initialize trainer before training 
        virtual void init_trainer( void ){
            if( strcmp( name_feat_user , "NULL") ) feat_user.load( name_feat_user );
            if( strcmp( name_feat_item , "NULL") ) feat_item.load( name_feat_item );
            tmp_ufactor = clone( model.W_user[0] );
            tmp_ifactor = clone( model.W_item[0] );
            // lazy decay
            this->sample_counter = 0;
            if( param.reg_global >= 4 ) {
                ref_global = new unsigned[ model.param.num_global ];
                memset( ref_global, 0, sizeof(unsigned)*model.param.num_global );
            } 
            if( param.reg_method >= 4 ){
                ref_user   = new unsigned[ model.param.num_user ];
                if( model.param.common_latent_space == 0 ){
                    ref_item = new unsigned[ model.param.num_item ];
                }else{
                    ref_item = ref_user; 
                }
                memset( ref_user, 0, sizeof(unsigned)*model.param.num_user );
                memset( ref_item, 0, sizeof(unsigned)*model.param.num_item );
            }
            // SVD++ style
            if( model.mtype.model_type == svd_type::SVD_FEATURE_PLUS ){
                tmp_ufeedback = clone( model.W_user[0] );
                old_ufeedback = clone( model.W_user[0] );
            }
        }
    private:        
        inline static void reg_L1( float &w, float wd ){
            if( w > wd ) w -= wd;
            else 
                if( w < -wd ) w += wd;
                else w = 0.0f;
        }
        inline static void project( CTensor1D w, float B ){
            float sum = cpu_only::dot( w, w );
            if( sum > B ){
                w *= sqrtf( B / sum );
            }            
        }

        inline void reg_global( const unsigned gid ){
            float lambda = param.learning_rate * g_param.get_wd( gid, param.wd_global );
            if( gid >= param.num_regfree_global ){ 
                switch( param.reg_global ){
                case 0: model.g_bias[ gid ] *= ( 1.0f - lambda ); break;
                case 1: reg_L1( model.g_bias[ gid ], lambda ); break;
                case 4: {// lazy L2 decay
                    float k = static_cast<float>( ref_global[gid] - sample_counter );
                    model.g_bias[ gid ] *= expf( logf( 1.0f - lambda ) * k );
                    ref_global[ gid ] = sample_counter;
                    break;
                }
                case 5: {// lazy L1 decay
                    float k = static_cast<float>( ref_global[gid] - sample_counter );
                    reg_L1( model.g_bias[ gid ], lambda * k );
                    ref_global[ gid ] = sample_counter;
                    break;                    
                }
                default:
                    apex_utils::error("unknown global decay method");
                }
            }
        }
        inline void reg_user( const unsigned uid ){
            // regularize factor 
            float wd =u_param.get_wd( uid, param.wd_user );
            float lambda = param.learning_rate * wd;
            switch( param.reg_method ){
            case 0: model.W_user[ uid ] *= ( 1.0f - lambda ); break;
            case 1:{
                CTensor1D w;
                w = model.W_user[ uid ];
                tensor::regularize_L1( w, lambda ); 
                break;                
            }
            case 2: project( model.W_user[ uid ], wd ); break;
            case 4: {// lazy L2 decay
                float k = static_cast<float>( ref_user[uid] - sample_counter );
                model.W_user[ uid ] *= expf( logf( 1.0f - lambda ) * k );
                ref_user[ uid ] = sample_counter;
                break;
            }
            case 5: {// lazy L1 decay
                CTensor1D w;
                w = model.W_user[ uid ];
                float k = static_cast<float>( ref_user[uid] - sample_counter );
                tensor::regularize_L1( w, lambda * k );
                ref_user[ uid ] = sample_counter;
                break;                    
            }
            default:apex_utils::error( "unknown reg_method" );
            }
            // only do L2 decay for bias
            if( model.param.no_user_bias == 0 ){
                model.u_bias[ uid ] *= ( 1.0f - param.learning_rate * param.wd_user_bias );
            }
        }
        inline void reg_item( const unsigned iid ){
            CTensor1D w;           
            float wd = i_param.get_wd( iid, param.wd_item );
            float lambda = param.learning_rate * wd;
            switch( param.reg_method ){
            case 0: model.W_item[ iid ] *= ( 1.0f - lambda ); break;
            case 1:{
                CTensor1D w;
                w = model.W_item[ iid ];
                tensor::regularize_L1( w, lambda ); 
                break;
            }
            case 2: project( model.W_item[ iid ], wd ); break;
            case 4: {// lazy L2 decay
                float k = static_cast<float>( ref_item[iid] - sample_counter );
                model.W_item[ iid ] *= expf( logf( 1.0f - lambda ) * k );
                ref_item[ iid ] = sample_counter;
                break;
            }
            case 5: {// lazy L1 decay
                CTensor1D w;
                w = model.W_item[ iid ];
                float k = static_cast<float>( ref_item[iid] - sample_counter );
                tensor::regularize_L1( w, lambda * k );
                ref_item[ iid ] = sample_counter;
                break;                    
            }
            default:apex_utils::error( "unknown reg_method" );
            }
            // only do L2 decay for bias
            model.i_bias[ iid ] *= ( 1.0f - param.learning_rate * param.wd_item_bias );
        }

        // do regularization
        inline void regularize( const SVDFeatureCSR::Elem feature, bool is_after_update ){            
            // when reg_method>=3, regularization is performed before update
            if( ( is_after_update && param.reg_global < 4) || 
                (!is_after_update && param.reg_global >=4)  ){ 
                for( int i = 0; i < feature.num_global; i ++ ){
                    this->reg_global( feature.index_global[i] );
                }
            }
            if( ( is_after_update && param.reg_method < 4) || 
                (!is_after_update && param.reg_method >=4)  ){ 
                for( int i = 0; i < feature.num_ufactor; i ++ ){
                    this->reg_user( feature.index_ufactor[i] );
                    SparseFeatureArray<float>::Vector vec = feat_user[ feature.index_ufactor[i] ];
                    for( int j = 0; j < vec.size(); j ++ ){
                        this->reg_user( vec[j].index );
                    }
                }
                for( int i = 0; i < feature.num_ifactor; i ++ ){                
                    this->reg_item( feature.index_ifactor[i] );
                    SparseFeatureArray<float>::Vector vec = feat_item[ feature.index_ifactor[i] ];
                    for( int j = 0; j < vec.size(); j ++ ){
                        this->reg_item( vec[j].index );
                    }
                }
            }
        }
    private:
        inline double calc_bias( const SVDFeatureCSR::Elem &feature,
                                 const CTensor1D &u_bias, 
                                 const CTensor1D &i_bias, 
                                 const CTensor1D &g_bias ){
            double sum = 0.0f;
            for( int i = 0; i < feature.num_global; i ++ ){
                const unsigned gid = feature.index_global[i];
                apex_utils::assert_true( gid < (unsigned)model.param.num_global, "global feature index exceed setting" );
                sum += feature.value_global[i] * g_bias[ gid ];
            }
                        
            if( model.param.no_user_bias == 0 ){
                for( int i = 0; i < feature.num_ufactor; i ++ ){
                    const unsigned uid = feature.index_ufactor[i];
                    apex_utils::assert_true( uid < (unsigned)model.param.num_user, "user feature index exceed bound" );
                    sum += feature.value_ufactor[i] * u_bias[ uid ];
                    // extra feature
                    SparseFeatureArray<float>::Vector vec = feat_user[ uid ];
                    for( int j = 0; j < vec.size(); j ++ ){
                        sum += u_bias[ vec[j].index ] * vec[j].value;
                    }
                }
                // SVD++ style
                if( model.mtype.model_type == svd_type::SVD_FEATURE_PLUS ){
                    sum += tmp_ufeedback_bias;
                }                
            }
             
            for( int i = 0; i < feature.num_ifactor; i ++ ){
                const unsigned iid = feature.index_ifactor[i];
                const float    ival= feature.value_ifactor[i];
                apex_utils::assert_true( iid < (unsigned)model.param.num_item, "item feature index exceed bound" );
                sum +=  ival * i_bias[ iid ];
                // extra feature
                SparseFeatureArray<float>::Vector vec = feat_item[ iid ];
                for( int j = 0; j < vec.size(); j ++ ){
                    sum += i_bias[ vec[j].index ] * vec[j].value * ival;
                }
            }
            
            return sum;
        }
        inline void prepare_tmp( const SVDFeatureCSR::Elem &feature ){ 
            // SVD++ style
            if( model.mtype.model_type == svd_type::SVD_FEATURE_PLUS ){
                tensor::copy( tmp_ufactor, tmp_ufeedback ); 
            }else{
                tmp_ufactor = 0.0f;
            }
            tmp_ifactor = 0.0f;

            for( int i = 0; i < feature.num_ufactor; i ++ ){
                const unsigned uid = feature.index_ufactor[i];
                apex_utils::assert_true( uid < (unsigned)model.param.num_user, "user feature index exceed bound" );

                tmp_ufactor += model.W_user[ uid ] * feature.value_ufactor[i];

                // extra feature
                SparseFeatureArray<float>::Vector vec = feat_user[ uid ];
                for( int j = 0; j < vec.size(); j ++ ){
                    tmp_ufactor += model.W_user[ vec[j].index ] * vec[j].value;
                }               
            }            
            for( int i = 0; i < feature.num_ifactor; i ++ ){
                const unsigned iid = feature.index_ifactor[i];
                const float    ival= feature.value_ifactor[i];
                tmp_ifactor += model.W_item[ iid ] * ival;

                // extra feature
                SparseFeatureArray<float>::Vector vec = feat_item[ iid ];
                for( int j = 0; j < vec.size(); j ++ ){
                    tmp_ifactor += model.W_item[ vec[j].index ] * vec[j].value * ival;
                }
            }            
        }
        
        inline float pred( const SVDFeatureCSR::Elem &feature ){ 
            double sum = model.param.base_score + 
                this->calc_bias( feature, model.u_bias, model.i_bias, model.g_bias );
            
            this->prepare_tmp( feature );

            sum += apex_tensor::cpu_only::dot( tmp_ufactor, tmp_ifactor );            
            
            return active_type::map_active( (float)sum, model.mtype.active_type ); 
        }
        
        inline void update_no_decay( const SVDFeatureCSR::Elem &feature ){ 
            float err = active_type::cal_grad( feature.label, this->pred( feature ), model.mtype.active_type );

            for( int i = 0; i < feature.num_global; i ++ ){
                const unsigned gid = feature.index_global[i];                
                model.g_bias[ gid ] += param.learning_rate * err * feature.value_global[i];
            }
                
            for( int i = 0; i < feature.num_ufactor; i ++ ){
                const unsigned uid = feature.index_ufactor[i];                
                float scale = param.learning_rate * err * feature.value_ufactor[i];
                    
                model.W_user[ uid ] += scale * tmp_ifactor;

                if( model.param.no_user_bias == 0 ){ 
                    model.u_bias[ uid ] += scale;
                }
                // extra feature
                SparseFeatureArray<float>::Vector vec = feat_user[ uid ];
                for( int j = 0; j < vec.size(); j ++ ){
                    float sc = param.learning_rate * err * vec[j].value;                    
                    model.W_user[ vec[j].index ] += sc * tmp_ifactor;
                    if( model.param.no_user_bias == 0 ){
                        model.u_bias[ vec[j].index ] += sc;
                    }
                }
            }

            for( int i = 0; i < feature.num_ifactor; i ++ ){
                const unsigned iid = feature.index_ifactor[i];
                const float    ival= feature.value_ifactor[i];
                float scale = param.learning_rate * err * ival;
                model.W_item[ iid ] += scale * tmp_ufactor;                 
                model.i_bias[ iid ] += scale;

                // extra feature
                SparseFeatureArray<float>::Vector vec = feat_item[ iid ];
                for( int j = 0; j < vec.size(); j ++ ){
                    float sc = param.learning_rate * err * vec[j].value * ival;
                    model.i_bias[ vec[j].index ] += sc;
                    model.W_item[ vec[j].index ] += sc * tmp_ufactor;
                }
            }
            
            // SVD++ style, only support L2 regularization
            if( model.mtype.model_type == svd_type::SVD_FEATURE_PLUS ){
                float lr = param.learning_rate * param.scale_lr_ufeedback;
                tmp_ufeedback += lr * err * norm_ufeedback * tmp_ifactor;
                tmp_ufeedback *= ( 1.0f - lr * param.wd_ufeedback );
                if( model.param.no_user_bias == 0 ){
                    tmp_ufeedback_bias += lr * err * norm_ufeedback;
                    tmp_ufeedback_bias *= ( 1.0f  - lr * param.wd_ufeedback_bias );
                }
            }
        }
        
        inline void update_inner( const SVDFeatureCSR::Elem &feature ){ 
            this->regularize( feature, false );
            this->update_no_decay( feature );
            this->sample_counter ++;
            this->regularize( feature, true );
        }        
    public:        
        virtual void update( const SVDFeatureCSR::Elem &feature ){             
            this->update_inner( feature );
        }
        virtual float predict( const SVDFeatureCSR::Elem &feature ){ 
            return this->pred( feature );
        }
        virtual void set_round( int nround ){
            if( param.decay_learning_rate != 0 ){
                apex_utils::assert_true( round_counter <= nround, "round counter restriction" );
                while( round_counter < nround ){
                    param.learning_rate *= param.decay_rate;
                    round_counter ++;
                }
            }
        }
    private:
        // SVD++ style
        inline void prepare_ufeedback( const SVDPlusBlock &data ){ 
            norm_ufeedback = 0.0f;
            tmp_ufeedback = 0.0f; tmp_ufeedback_bias = 0.0f;
            for( int i = 0; i < data.num_ufeedback; i ++ ){
                const unsigned fid = data.index_ufeedback[i];
                const float    val = data.value_ufeedback[i];
                apex_utils::assert_true( fid < static_cast<unsigned>( model.param.num_ufeedback ), 
                                         "ufeedback id exceed bound" );
                tmp_ufeedback += model.W_ufeedback[ fid ] * val;
                norm_ufeedback+= val * val;
                if( model.param.no_user_bias == 0 ){
                    tmp_ufeedback_bias += model.ufeedback_bias[ fid ] * val;
                }
            }            
        }        
        inline void update_ufeedback( const SVDPlusBlock &data ){ 
            if( data.num_ufeedback == 0 ) return;
            tmp_ufeedback -= old_ufeedback;
            tmp_ufeedback_bias -= old_ufeedback_bias;
            tmp_ufeedback *= 1.0f/ norm_ufeedback;
            tmp_ufeedback_bias *= 1.0f / norm_ufeedback;
            for( int i = 0; i < data.num_ufeedback; i ++ ){
                const unsigned fid = data.index_ufeedback[i];
                const float    val = data.value_ufeedback[i];
                model.W_ufeedback[ fid ] += tmp_ufeedback * val;
                if( model.param.no_user_bias == 0 ){
                    model.ufeedback_bias[ fid ] += tmp_ufeedback_bias * val;
                }
            }
        }
    public:
        // SVD++ style
        virtual void update( const SVDPlusBlock &data ){ 
            // calculate and backup feedback in the first block
            if( data.extend_tag == svdpp_tag::DEFAULT || data.extend_tag == svdpp_tag::START_TAG ){
                this->prepare_ufeedback( data );
                old_ufeedback_bias = tmp_ufeedback_bias;
                tensor::copy( old_ufeedback, tmp_ufeedback );            
            }
            // update 
            for( int i = 0; i < data.data.num_row; i ++ ){
                this->update_inner( data.data[i] );
            }
            // update feedback data in the last block
            if( data.extend_tag == svdpp_tag::DEFAULT || data.extend_tag == svdpp_tag::END_TAG ){
                this->update_ufeedback( data );
            }
        }
        virtual void predict( std::vector<float> &p, const SVDPlusBlock &data ){ 
            p.clear();
            if( data.extend_tag == svdpp_tag::DEFAULT || data.extend_tag == svdpp_tag::START_TAG ){
                this->prepare_ufeedback( data );
            }
            for( int i = 0; i < data.data.num_row; i ++ ){
                p.push_back( this->pred( data.data[i] ) );
            }
        }
    };
};

#ifndef _CREATE_SVD_TRAINER_
namespace apex_svd{
    ISVDTrainer *create_svd_trainer( SVDTypeParam mtype ){
        return new apex_svd::SVDFeature( mtype );
    }
};
#endif
