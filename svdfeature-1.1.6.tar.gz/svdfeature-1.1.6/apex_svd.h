/*
 *  Copyright 2009-2010 APEX Data & Knowledge Management Lab, Shanghai Jiao Tong University
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

/*!
 * \file apex_svd.h
 * \brief header defining the interface of SVD-solver 
 * \author Tianqi Chen: tqchen@apex.sjtu.edu.cn
 */
#ifndef _APEX_SVD_H_
#define _APEX_SVD_H_

#include "apex_svd_data.h"
#include "apex_svd_model.h"

/*! \brief namespace of SVDFeature */
namespace apex_svd{    
    /*! 
     * \brief virtual interface of SVDFeature-solver
     */
    class ISVDTrainer{
    public:
        // interface for model setting and loading
        // this allows different implementation to use their own model structure
        /*! 
         * \brief set parameters from outside 
         * \param name name of the parameter
         * \param val  value of the parameter
         */
        virtual void set_param( const char *name, const char *val ) = 0;
        /*! 
         * \brief load model from file
         * \param fi file pointer to input file
         */        
        virtual void load_model( FILE *fi ) = 0;
        /*! 
         * \brief save model file
         * \param fo file pointer to output file
         */        
        virtual void save_model( FILE *fo ) = 0;
        /*! 
         * \brief random initialize model parameters for first training,
         * a model can either be random initialized using init_model 
         * or be load by load_model
         */        
        virtual void init_model( void ) = 0;
        /*! 
         * \brief initialize solver before training, called before training
         * this function is reserved for solver to allocate necessary space and 
         * do other preparations 
         */        
        virtual void init_trainer( void ) = 0;
    public:        
        // interface for training procedure
        /*! 
         * \brief set current round number, 
         *   this function is before called every round, reserved for solver to set round dependent learning_rate, etc.
         * \param nround current round number
         */
        virtual void set_round( int nround ){ apex_utils::error("not implemented"); }
        /*! 
         * \brief update model using feature vector, random order input
         * \param feature input feature
         * \sa SVDFeatureCSR
         */
        virtual void update( const SVDFeatureCSR::Elem &feature ){ apex_utils::error("not implemented"); }
        /*! 
         * \brief predict the rate for given feature 
         * \param feature input feature
         * \sa SVDFeatureCSR
         */
        virtual float predict( const SVDFeatureCSR::Elem &feature ){ apex_utils::error("not implemented"); return 0.0f; }
    public:
        // SVD++ user-wise style update, for user grouped input
        /*! 
         * \brief update model, user grouped input, used in efficient SVD++ training and rank
         * \param data input user grouped data
         * \sa SVDPlusBlock
         */
        virtual void update( const SVDPlusBlock &data ){ apex_utils::error("not implemented"); }
        /*! 
         * \brief predict for a given user grouped data
         * \param pred output of the predicted value
         * \param data input user grouped data
         * \sa SVDPlusBlock
         */
        virtual void predict( std::vector<float> &pred, const SVDPlusBlock &data ){ apex_utils::error("not implemented"); }
    public:
        virtual ~ISVDTrainer(){}
    };
};

namespace apex_svd{
    /*! 
     * \brief create a SVD trainer according to the specified type
     *  when make a new extension of the ISVDTrainer, rewrite this function to add the variant to extesion.
     *
     * Guide for customization: user can write(or modify from the provided implementation) a new version of 
     *  solver, and rewrite this function to return the new solver.
     *
     * \param mtype specify the type of the solver
     * \return a pointer to a solver
     * \sa SVDTypeParam
     */
    ISVDTrainer *create_svd_trainer( SVDTypeParam mtype );
};
#endif

